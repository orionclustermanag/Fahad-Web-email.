// Simple front-end to talk to server endpoints and render basic mail UI.
let creds = null; // { imap: {...}, smtp: {...} }
const statusEl = document.getElementById('status');
const listEl = document.getElementById('list');
const controlsEl = document.getElementById('controls');

function setStatus(txt) { statusEl.textContent = txt; }

document.getElementById('connectBtn').addEventListener('click', showConnectForm);
document.getElementById('disconnectBtn').addEventListener('click', () => { creds = null; setStatus('Disconnected'); listEl.innerHTML = ''; controlsEl.innerHTML = ''; });

document.getElementById('inboxBtn').addEventListener('click', () => fetchMailbox('INBOX'));
document.getElementById('sentBtn').addEventListener('click', () => fetchMailbox('Sent'));
document.getElementById('spamBtn').addEventListener('click', () => fetchMailbox('Spam'));
document.getElementById('trashBtn').addEventListener('click', () => fetchMailbox('Trash'));
document.getElementById('composeBtn').addEventListener('click', showCompose);

function showConnectForm() {
  controlsEl.innerHTML = `
    <h3>Connect IMAP/SMTP Account</h3>
    <div class="small">For Gmail use an App Password or OAuth2 (not included in this starter).</div>
    <label>IMAP host</label><input id="imapHost" type="text" value="imap.gmail.com" />
    <label>IMAP port</label><input id="imapPort" type="number" value="993" />
    <label>IMAP TLS (true/false)</label><input id="imapTls" type="text" value="true" />
    <label>IMAP user (email)</label><input id="imapUser" type="text" value="" />
    <label>IMAP password</label><input id="imapPass" type="password" value="" />
    <hr />
    <label>SMTP host</label><input id="smtpHost" type="text" value="smtp.gmail.com" />
    <label>SMTP port</label><input id="smtpPort" type="number" value="465" />
    <label>SMTP secure (true/false)</label><input id="smtpSecure" type="text" value="true" />
    <label>SMTP user (email)</label><input id="smtpUser" type="text" value="" />
    <label>SMTP password</label><input id="smtpPass" type="password" value="" />
    <div style="margin-top:8px;"><button id="saveConn" class="btn">Save & Test</button></div>
  `;
  document.getElementById('saveConn').addEventListener('click', async () => {
    const imap = { host: document.getElementById('imapHost').value, port: parseInt(document.getElementById('imapPort').value), tls: document.getElementById('imapTls').value === 'true', user: document.getElementById('imapUser').value, password: document.getElementById('imapPass').value };
    const smtp = { host: document.getElementById('smtpHost').value, port: parseInt(document.getElementById('smtpPort').value), secure: document.getElementById('smtpSecure').value === 'true', user: document.getElementById('smtpUser').value, password: document.getElementById('smtpPass').value };
    setStatus('Testing connection...');
    try {
      const resp = await fetch('/api/test', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({ imap, smtp }) });
      const data = await resp.json();
      if (data.ok) {
        creds = { imap, smtp };
        setStatus('Connected as ' + imap.user);
        controlsEl.innerHTML = '';
        fetchMailbox('INBOX');
      } else {
        setStatus('Connection failed: ' + (data.error || 'unknown'));
      }
    } catch (e) {
      setStatus('Error: ' + e.message);
    }
  });
}

async function fetchMailbox(mailbox) {
  if (!creds) return alert('Connect first');
  setStatus('Fetching ' + mailbox + '...');
  listEl.innerHTML = '';
  try {
    const resp = await fetch('/api/mailbox', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({ creds, mailbox }) });
    const data = await resp.json();
    if (!data.ok) return setStatus('Error: ' + data.error);
    setStatus('Showing ' + mailbox);
    renderMessages(data.messages);
  } catch (e) {
    setStatus('Error: ' + e.message);
  }
}

function renderMessages(messages) {
  listEl.innerHTML = '';
  if (!messages || messages.length === 0) { listEl.innerHTML = '<div class="small">No messages</div>'; return; }
  messages.forEach(m => {
    const div = document.createElement('div');
    div.className = 'mail-item';
    div.innerHTML = `<div><strong>${m.subject || '(no subject)'}</strong></div>
      <div class="small">${m.from || ''} · ${m.date ? new Date(m.date).toLocaleString() : ''}</div>
      <div style="margin-top:6px;">${m.text ? m.text.slice(0,300) : ''}</div>
      <div style="margin-top:6px;"><button class="btn viewBtn">View</button></div>`;
    div.querySelector('.viewBtn').addEventListener('click', () => showMessage(m));
    listEl.appendChild(div);
  });
}

function showMessage(m) {
  controlsEl.innerHTML = `<h3>${m.subject || '(no subject)'}</h3><div class="small">From: ${m.from || ''} · To: ${m.to || ''} · ${m.date ? new Date(m.date).toLocaleString() : ''}</div><hr /><div>${m.html || m.text || ''}</div>`;
}

function showCompose() {
  controlsEl.innerHTML = `
    <h3>Compose</h3>
    <label>To</label><input id="compTo" type="text" />
    <label>Subject</label><input id="compSubject" type="text" />
    <label>Body</label><textarea id="compBody" rows="8"></textarea>
    <div style="margin-top:8px;"><button id="sendBtn" class="btn">Send</button></div>
  `;
  document.getElementById('sendBtn').addEventListener('click', async () => {
    const mail = { from: creds.smtp.user, to: document.getElementById('compTo').value, subject: document.getElementById('compSubject').value, text: document.getElementById('compBody').value };
    try {
      const resp = await fetch('/api/send', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({ smtp: creds.smtp, mail }) });
      const data = await resp.json();
      if (data.ok) { alert('Sent'); } else alert('Send error: ' + data.error);
    } catch (e) { alert('Send error: ' + e.message); }
  });
}
